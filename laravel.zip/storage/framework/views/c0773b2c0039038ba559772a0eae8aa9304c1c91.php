<!doctype html>
<html lang="ua">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(asset('/public/css/app.css')); ?>">

    <title><?php echo $__env->yieldContent('text-title'); ?> | Admin Panel</title>
</head>
<body>

<div  id="menu">
    <?php echo $__env->make('admin.includes.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<!-- /#menu.container -->
<div id="alertBlock">
    <?php echo $__env->make('admin.includes.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<!-- /#alertBlock -->
    <main id="content" class="mt-3">
        <?php echo $__env->yieldContent('content'); ?>
    </main>
    <!-- /#content -->

<script src="<?php echo e(asset('/public/js/app.js')); ?>"></script>
</body>
</html>
<?php /**PATH F:\SERVER_ONE\OpenServer\domains\service.laravel.lc.io\resources\views/admin/layouts/app.blade.php ENDPATH**/ ?>