<?php $__env->startSection('text-title'); ?> Відстеження переходів <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <h3 class="text-center">Лог переходів по вашим скороченням.</h3>
        </div>
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <ul class="list-group">
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item">
                            <div class="d-flex justify-content-between">
                                <span class="d-block"> <?php echo e($item->ip); ?> </span>
                                <span class="d-block"> <?php echo e($item->user_agent); ?> </span>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <div class="py-3 d-flex justify-content-center align-items-center">
                    <?php echo e($data->links()); ?>

                </div>
            </div>
            <!-- /.col-lg-8 -->
        </div>
        <!-- /.row -->
        <!-- /.row -->
    </div>
    <!-- /.container -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\SERVER_ONE\OpenServer\domains\service.laravel.lc.io\resources\views/logList.blade.php ENDPATH**/ ?>