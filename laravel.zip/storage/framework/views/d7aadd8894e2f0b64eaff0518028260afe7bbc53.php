<?php $__env->startSection('text-title'); ?> Головна <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <?php if(!auth()->check()): ?>
                    <h3 align="center">Ви не авторизовані</h3>
                <?php else: ?>
                    <form action="<?php echo e(route('add-short')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="" ></label>
                            <input
                                type="text"
                                id="url"
                                name="url"
                                placeholder="Вставте посилання для скорочення"
                                class="form-control"
                                value="<?php echo e(session('short_link')); ?>"
                            >
                            <!-- /.form-control -->
                        </div>
                        <!-- /.form-group -->
                        <div class="form-group">
                            <button class="btn btn-success">Додати</button>
                        </div>
                    </form>
                    <div class="mt-3 px-1 py-2">
                        <h4 class="text-center">Ваші скорочення</h4>
                        <ul class="list-group">
                            <li class="list-group-item">
                                <div class="d-flex justify-content-between align-items-center py-1">
                                    <span class="d-block">
                                        Скорочення
                                    </span>
                                    <span class="d-block">
                                        Переходи
                                    </span>
                                    <span class="d-block">
                                        Відстежити (Лог переходів)
                                    </span>
                                </div>
                            </li>
                            <?php $__currentLoopData = $my_shorts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="list-group-item">
                                    <div class="d-flex justify-content-between align-items-center py-1">
                                    <span class="d-block">
                                        <a href="<?php echo e(asset('/' . $item->short_id)); ?>">
                                            <?php echo e(substr($item->url, 0, 20)); ?>...
                                        </a>

                                    </span>
                                        <span class="d-block">
                                        <?php echo e($item->linked); ?>

                                    </span>
                                        <span class="d-block">
                                        <a href="/log/<?php echo e($item->short_id); ?>">
                                            Відстежити
                                        </a>
                                    </span>
                                    </div>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <div class="d-flex py-3 mt-1 justify-content-center align-items-center">
                            <?php echo e($my_shorts->links()); ?>

                        </div>
                    </div>
                    <!-- /.px-1 -->
                <?php endif; ?>
            </div>
            <!-- /.col-md-6 -->
            <div class="col-md-6">
                <p>Додайте посилання для скорочення</p>
                <p> <?php echo e(session('short_link')); ?> </p>
            </div>
            <!-- /.col-md-6 -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container -->



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\SERVER_ONE\OpenServer\domains\service.laravel.lc.io\resources\views/welcome.blade.php ENDPATH**/ ?>