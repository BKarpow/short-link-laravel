<template>

</template>

<script>
    export default {
        props: ['urlAdd', 'urlGet', 'postId'],

    }
</script>
