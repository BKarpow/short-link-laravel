<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UsersAvatar extends Model
{
    //
}
