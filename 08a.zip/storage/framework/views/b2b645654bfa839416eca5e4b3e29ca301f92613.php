<?php if($errors->any()): ?>
    <div class="container my-2" id="error_box">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="alert alert-danger">
                    <strong>
                        <h3><i class="fas fa-bug"></i> Error list!</h3>
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($err); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </strong>
                </div>
            </div>
            <!-- /.col-md-10 -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /#error_box.container -->
<?php endif; ?>
<?php /**PATH F:\SERVER_ONE\OpenServer\domains\service.laravel.lc.io\resources\views/includes/error.blade.php ENDPATH**/ ?>