<?php $__env->startSection('text-title'); ?> Створення статті <?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
    <!-- include summernote css/js -->
    <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.js"></script>
    <script>
        $(document).ready(function() {
            $('.editors').summernote({
                placeholder: 'Опис',
                tabsize: 2,
                height: 350,
                callbacks: {
                    onImageUpload: function (files) {
                        const el = $(this);
                        uploadFile(files[0], el);
                    }
                }
            });
        });

        const uploadFile = (file, el) => {
            const fData = new FormData()
            fData.append('file', file)
            axios.post('<?php echo e(route('upload')); ?>', fData)
                .then(response => {
                    const path = response.data.path
                    console.log('File upload', path)
                    el.summernote('insertImage', path);
                })
                .catch(err => {
                    console.error(err)
                })
        }

        function sendFile(file, el) {
            var  data = new FormData();
            data.append("file", file);
            var url = '<?php echo e(route('upload')); ?>';
            $.ajax({
                data: data,
                type: "POST",
                headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                url: url,
                cache: false,
                contentType: false,
                processData: false,
                success: function(url2) {
                    el.summernote('insertImage', url2);
                }
            });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <form action="<?php echo e(route('create-post-action')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="title">Заголовок</label>
                        <input type="text" name="title" class="form-control" placeholder="Заголовок">
                        <!-- /.form-control -->
                    </div>
                    <!-- /.form-group -->
                    <div class="form-group">
                        <image-selector-component></image-selector-component>
                    </div>
                    <!-- /.form-group -->
                    <field-tags-component
                        uri-set="<?php echo e(route('tags.ajax.new')); ?>"
                        uri-get="<?php echo e(route('tags.ajax.all')); ?>"
                    ></field-tags-component>

                    <div class="form-group">
                        <label for="category_id">Оберіть категорію</label>
                        <select name="category_id" id="category_id" class="form-control">
                            <option selected="">Обрати категорію</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->title); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <!-- /#.form-control -->
                    </div>
                    <!-- /.form-group -->
                    <div class="form-group">
                        <label for="short_text">Короткий опис</label>
                        <textarea name="short_text" id="short_text" cols="30" rows="10" class="editors form-control"></textarea>
                        <!-- /#.form-control -->
                    </div>
                    <!-- /.form-group -->
                    <div class="form-group">
                        <label for="text">Стаття</label>
                        <textarea name="text" id="text" cols="30" rows="10" class="editors"></textarea>
                        <!-- /#.form-control -->
                    </div>
                    <!-- /.form-group -->
                    <div class="form-group d-flex justify-content-center">
                        <button class="btn btn-success btn-lg">Додати статтю</button>
                        <!-- /.btn -->
                    </div>
                    <!-- /.form-group -->
                </form>
            </div>
            <!-- /.col_md_10 -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\SERVER_ONE\OpenServer\domains\service.laravel.lc.io\resources\views/admin/pages/posts/create.blade.php ENDPATH**/ ?>