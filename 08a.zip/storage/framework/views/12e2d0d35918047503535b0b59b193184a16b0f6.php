<?php if(!empty(session('status'))): ?>
<div id="alertBox" class="container my-2 animate__animated">
    <div class="row justify-content-center align-items-center">
        <div class="alert alert-success">
            <strong><?php echo e(session('status')); ?></strong>
        </div>
    </div>
</div>
<?php else: ?>
    <?php if($errors->any()): ?>
        <div id="errorBox" class="container my-2 animate__animated">
            <div class="row justify-content-center align-items-center">
                <div class="col-lg-9">
                    <div class="alert alert-danger">
                        <h4>Є омилки(ф)</h4>
                        <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
                <!-- /.col-lg-9 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container my-2 -->
    <?php endif; ?>


<?php endif; ?>
<?php /**PATH F:\SERVER_ONE\OpenServer\domains\service.laravel.lc.io\resources\views/admin/includes/alert.blade.php ENDPATH**/ ?>