<div class="container">
    <div class="row">
        <div class="col">
            <h3 class="text-center">Вам повідомлення</h3>
            <!-- /.text-center -->
        </div>
        <!-- /.col -->
    </div>
    <!-- /.row -->
    <div class="row justify-content-center">
        <div class="col-md-8">
            <?php echo e($send_text); ?>

        </div>
        <!-- /.col-md-8 -->
    </div>
    <!-- /.row -->
</div>
<!-- /.container -->
<?php /**PATH F:\SERVER_ONE\OpenServer\domains\service.laravel.lc.io\resources\views/emails/send.blade.php ENDPATH**/ ?>