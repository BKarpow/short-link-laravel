<?php $__env->startSection('text-title'); ?> Список міток <?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        window.onload = function(){

        }
    </script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-9">
                <h3>Мітки</h3>
                <div class="d-flex justify-content-between py-2">
                    <a href="" class="btn btn-primary btn-lg">
                        <i class="fas fa-plus-circle"></i>
                        Додати мітку
                    </a>
                    <!-- /.btn -->
                </div>
                <!-- /.d-flex -->
                <div class="table-response">
                    <table class="table">
                        <thead>
                        <tr>
                            <th>ID</th>
                            <th>Назва</th>
                            <th>Контроль</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td> <?php echo e($item->id); ?> </td>
                                <td> <?php echo e($item->name); ?> </td>
                                <td>
                                        <a href="<?php echo e(route('update-page', ['alias'=>'ggg'])); ?>">
                                            <i class="fas fa-edit"></i>
                                        </a> |
                                    <del-link
                                        delete-link="<?php echo e(route('tags.delete', ['tag_id' => $item->id])); ?>"
                                        message-delete-confirm="Видалити <?php echo e($item->name); ?> ?"
                                    >
                                        <i class="fas fa-trash"></i>
                                    </del-link>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <!-- /.table -->
                </div>
                <!-- /.table-response -->
                <div class="d-flex justify-content-center align-items-center my-2" id="paginate">
                    <?php echo e($data->links()); ?>

                </div>
                <!-- /#paginate.d-flex -->
            </div>
            <!-- /.col-md-9 -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\SERVER_ONE\OpenServer\domains\service.laravel.lc.io\resources\views/admin/pages/tags/list.blade.php ENDPATH**/ ?>