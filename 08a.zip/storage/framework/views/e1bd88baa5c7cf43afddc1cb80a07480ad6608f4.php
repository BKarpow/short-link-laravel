<?php $__env->startSection('text-title'); ?> <?php echo e($data->post_title); ?> <?php $__env->stopSection(); ?>

<?php $__env->startSection('meta'); ?>
    <meta name="description" content="<?php echo e($data->short_text); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-10 p-2">
                <h2 class="display-3"><?php echo e($data->post_title); ?></h2>
                <div class="meta-post-box">
                    <span>Автор: <?php echo e($data->user_name); ?></span> ,
                    <span>Категорія: <?php echo e($data->title); ?></span> ,
                    <span>Створено: <?php echo e($data->created_at); ?></span> ,
                    <span>Переглядів: <?php echo e($data->previews); ?></span>
                    <span>
                        <i class="fas fa-tags"></i>
                        <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(route('post.show.tag', ['tag_name'=>$tag->alias])); ?>">
                                <?php echo e($tag->name); ?>

                            </a>&nbsp;

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </span>
                </div>
                <div class="my-1 d-flex justify-content-center">
                    <img src="<?php echo e($data->main_img); ?>" alt="no photo">
                </div>
                <!-- /.my-1 -->
                <div class="my-2">
                    <?php echo $data->text; ?>

                </div>
                <!-- /.my-2 -->
            </div>
        </div>
        <!-- /.row -->
        <div class="row mt-2 justify-content-center align-items-center">
          <div class="col-md-10">
              <comments
                  url-get-comments="<?php echo e(route('comments.post', ['post_id' => $data->post_id])); ?>"
                  url-add="<?php echo e(route('comments.add')); ?>"
                  post-id="<?php echo e($data->post_id); ?>"
                  <?php if(auth()->check()): ?>
                  auth="true"
                  <?php endif; ?>
              >
              </comments>
          </div>
          <!-- /.col-md-8 -->
        </div>
        <!-- /.rom mt-2 -->
    </div>
    <!-- /.container -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\SERVER_ONE\OpenServer\domains\service.laravel.lc.io\resources\views/pages/post/post.blade.php ENDPATH**/ ?>