<?php $__env->startSection('text-title'); ?> Додати медіа <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <form action="<?php echo e(route('media-add-action')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="title">Назва</label>
                        <input type="text" name="title" class="form-control">
                        <!-- /.form-control -->
                    </div>
                    <!-- /.form-group -->

                    <upload-component
                        route-delete="/admin/delete/image"
                        route-upload="/admin/upload/image"
                        name-field-file="file"
                    ></upload-component>

                    <div class="form-group">
                        <label for="description">Опис файлу</label>
                        <textarea
                            name="description"
                            cols="30"
                            rows="10"
                            placeholder="Опис файлу"
                            class="form-control"></textarea>
                        <!-- /.form-control -->
                    </div>
                    <!-- /.form-group -->
                    <div class="form-group d-flex justify-content-center">
                        <button class="btn btn-success btn-lg">Додати</button>
                    </div>
                    <!-- /.form-group -->
                </form>
            </div>
            <!-- /.col-md-10 -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\SERVER_ONE\OpenServer\domains\service.laravel.lc.io\resources\views/admin/pages/media/add.blade.php ENDPATH**/ ?>