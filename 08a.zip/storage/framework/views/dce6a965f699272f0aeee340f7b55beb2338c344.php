<?php $__env->startSection('text-title'); ?> Про нас <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="jumbotron">
                    <h1 class="display-4">Скорочення посилань</h1>
                    <p class="lead">
                        Цей сервіс дає змогу скорочувати посилання, та інструменти API
                    </p>
                    <p class="lead">
                        Для використання API звернітся за xymerone@gmail.com
                    </p>
                    <p class="lead">
                        Автор Богдан Карпов
                    </p>
                    <!-- /.lead -->
                    <hr class="my-4">
                    <a class="btn btn-primary btn-lg" href="tg://@BogdanKarpov" role="button">
                        <i class="fab fa-telegram-plane"></i>
                        Мій телеграм
                    </a>
                </div>
            </div>
            <!-- /.col-md-10 -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\SERVER_ONE\OpenServer\domains\service.laravel.lc.io\resources\views/pages/about.blade.php ENDPATH**/ ?>