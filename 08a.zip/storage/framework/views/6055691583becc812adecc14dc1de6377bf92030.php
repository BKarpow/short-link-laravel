<?php $__env->startSection('text-title'); ?> Список категорій <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-9">
                <h3>Список категорій</h3>
                <div class="table-response">
                    <table class="table">
                        <thead>
                        <tr>
                            <th>ID</th>
                            <th>Зображення</th>
                            <th>Назва</th>
                            <th>Контроль</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td> <?php echo e($item->id); ?> </td>
                            <td>
                                <div class="px-lg-1" style="width: 80px;">
                                    <img
                                        src="<?php echo e($item->icon_path); ?>"
                                        class="img-fluid"
                                        alt="Неммає зображення">
                                </div>
                            </td>
                            <td><?php echo e($item->title); ?></td>
                            <td>
                                <a href="<?php echo e(route('update-category', ['id'=>$item->id])); ?>">
                                    <i class="fas fa-edit"></i>
                                </a> |
                                <a href="<?php echo e(route('delete-category', ['id' => $item->id])); ?>">
                                    <i class="fas fa-trash"></i>
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <!-- /.table -->
                </div>
                <!-- /.table-response -->
                <div class="d-flex justify-content-center align-items-center my-2" id="paginate">
                    <?php echo e($data->links()); ?>

                </div>
                <!-- /#paginate.d-flex -->
            </div>
            <!-- /.col-md-9 -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\SERVER_ONE\OpenServer\domains\service.laravel.lc.io\resources\views/admin/pages/categoryposts/list.blade.php ENDPATH**/ ?>