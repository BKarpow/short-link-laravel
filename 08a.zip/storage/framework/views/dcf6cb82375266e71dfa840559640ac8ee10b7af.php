<?php $__env->startSection('text-title'); ?> Головна <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-10 py-3">
                <h4>Всі скорочення</h4>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                        <tr>
                            <th>ID</th>
                            <th>Ім'я користувача</th>
                            <th>URL</th>
                            <th>Short ID</th>
                            <th>Переходи</th>
                            <th>Останній перехід</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->id); ?></td>
                                <td><?php echo e($item->name); ?></td>
                                <td><?php echo e($item->url); ?></td>
                                <td><?php echo e($item->short_id); ?></td>
                                <td><?php echo e($item->linked); ?></td>
                                <td><?php echo e($item->updated_at); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="my-2 d-flex justify-content-center align-items-center">

                    <?php echo e($data->links()); ?>


                </div>
                <!-- /.my-2 d-flex -->
            </div>
            <!-- /.col-md-10 -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\SERVER_ONE\OpenServer\domains\service.laravel.lc.io\resources\views/admin/home.blade.php ENDPATH**/ ?>