<?php if(!empty($data)): ?>
    <?php $__env->startSection('text-title'); ?> Редагувати категорію <?php echo e($data->title); ?> <?php $__env->stopSection(); ?>
<?php else: ?>
    <?php $__env->startSection('text-title'); ?> Додати категорію <?php $__env->stopSection(); ?>
<?php endif; ?>



<?php $__env->startSection('content'); ?>
    <div id="app" class="container py-1">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <h3>Створення нової категорії</h3>
                <form
                    <?php if(!empty($data)): ?>
                        action="<?php echo e(route('update-category-action', ['id'=>$id])); ?>"
                    <?php else: ?>
                        action="<?php echo e(route('create-category-action')); ?>"
                    <?php endif; ?>
                    method="POST"
                >
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="title">Назва категорії</label>
                        <input
                            <?php if(!empty($data)): ?> value="<?php echo e($data->title); ?>" <?php endif; ?>
                            type="text"
                            name="title"
                            id="title"
                            class="form-control"
                            placeholder="Вкажіть назву нової категорії"
                        >
                        <!-- /.form-control -->
                    </div>
                    <!-- /.form-group -->

                    <div class="form-group">
                        <upload-component
                            route-delete="/admin/delete/image"
                            route-upload="/admin/upload/image"
                            name-field-file="icon_path"
                            <?php if(!empty($data)): ?>
                                default-src="<?php echo e($data->icon_path); ?>"
                            <?php endif; ?>
                        ></upload-component>
                    </div>
                    <!-- /.form-group -->

                    <?php if(empty($data)): ?>
                    <div class="form-group">
                        <label for="parent">Батківська категорія</label>
                        <select name="parent" id="parent" class="form-control">
                            <option disabled selected>Оберіть категорію</option>
                            <option value="0" >Без батьків(Головна)</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->title); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <!-- /#.form-control -->
                    </div>
                    <!-- /.form-group -->
                    <?php else: ?>
                        <input type="hidden" name="parent" value="<?php echo e($data->parent_category); ?>">
                    <?php endif; ?>
                    <div class="form-group">
                        <label for="description">Опис категорії</label>
                        <textarea
                            name="description"
                            id="description"
                            cols="30"
                            rows="10"
                            placeholder="Опишіть категорію"
                            class="form-control"><?php if(!empty($data)): ?><?php echo e($data->description); ?><?php endif; ?></textarea>
                        <!-- /#.form-control -->
                    </div>
                    <!-- /.form-group -->
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary btn-lg">
                            <?php if(!empty($data)): ?>
                                Оновити
                            <?php else: ?>
                                Додати
                            <?php endif; ?>
                        </button>
                    </div>
                    <!-- /.form-group -->
                </form>
            </div>
            <!-- /.col-md-10 -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\SERVER_ONE\OpenServer\domains\service.laravel.lc.io\resources\views/admin/pages/categoryposts/create.blade.php ENDPATH**/ ?>