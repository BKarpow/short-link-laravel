<?php if(!empty($data)): ?>
<?php $__env->startSection('text-title'); ?> Оновлення сторінки <?php echo e($data->title); ?> <?php $__env->stopSection(); ?>
<?php else: ?>
<?php $__env->startSection('text-title'); ?> Створення сторінки <?php $__env->stopSection(); ?>
<?php endif; ?>

<?php $__env->startSection('styles'); ?>
    <!-- include summernote css/js -->
    <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.js"></script>
    <script>
        $(document).ready(function() {
            $('.editors').summernote({
                placeholder: 'Опис',
                tabsize: 2,
                height: 350,
                callbacks: {
                    onImageUpload: function (files) {
                        const el = $(this);
                        uploadFile(files[0], el);
                    }
                }
            });
        });

        const uploadFile = (file, el) => {
            const fData = new FormData()
            fData.append('file', file)
            axios.post('<?php echo e(route('upload')); ?>', fData)
                .then(response => {
                    const path = response.data.path
                    console.log('File upload', path)
                    el.summernote('insertImage', path);
                })
                .catch(err => {
                    console.error(err)
                })
        }
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <form
                    <?php if(!empty($data)): ?>
                        action="<?php echo e(route('update-page-action')); ?>"
                    <?php else: ?>
                        action="<?php echo e(route('create-page-action')); ?>"
                    <?php endif; ?>

                    method="POST"
                >
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="title">Заголовок</label>
                        <?php if(!empty($data)): ?>
                            <input type="text"
                                   name="title"
                                   class=" form-control"
                                   placeholder="Заголовок"
                                   value="<?php echo e($data->title); ?>"
                            >
                            <!-- /.form-control -->
                        <?php else: ?>
                            <input type="text" name="title" class="form-control" placeholder="Заголовок">
                            <!-- /.form-control -->
                        <?php endif; ?>

                    </div>
                    <!-- /.form-group -->
                    <div class="form-group">
                        <label for="alias">URL (адреса сторінки)</label>
                        <?php if(!empty($data)): ?>
                            <h4>url: /page/<?php echo e($data->alias); ?></h4>
                            <input type="hidden" name="alias" value="<?php echo e($data->alias); ?>">
                        <?php else: ?>
                            <field-alias-component></field-alias-component>
                        <?php endif; ?>

                        <!-- /.form-control -->
                    </div>
                    <!-- /.form-group -->


                    <div class="form-group">
                        <label for="page">Сторінка</label>
                        <textarea name="page" id="page" cols="30" rows="10" class="editors"><?php if(!empty($data)): ?> <?php echo e($data->page); ?> <?php endif; ?></textarea>
                        <!-- /#.form-control -->
                    </div>
                    <!-- /.form-group -->
                    <div class="form-group d-flex justify-content-center">
                        <?php if(!empty($data)): ?>
                            <button class="btn btn-success btn-lg">Оновити сторінку</button>
                            <!-- /.btn -->
                        <?php else: ?>
                            <button class="btn btn-success btn-lg">Додати сторінку</button>
                            <!-- /.btn -->
                        <?php endif; ?>

                    </div>
                    <!-- /.form-group -->
                </form>
            </div>
            <!-- /.col_md_10 -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\SERVER_ONE\OpenServer\domains\service.laravel.lc.io\resources\views/admin/pages/page/create.blade.php ENDPATH**/ ?>