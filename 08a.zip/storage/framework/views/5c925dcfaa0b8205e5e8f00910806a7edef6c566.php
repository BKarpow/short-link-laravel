<?php $__env->startSection('text-title'); ?> <?php echo e($data->title); ?> <?php $__env->stopSection(); ?>

<?php $__env->startSection('meta'); ?>
    <meta name="description" content="<?php echo e(substr( strip_tags( $data->page), 0, 200)); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-10 p-2">
                <h2 class="display-3"><?php echo e($data->title); ?></h2>
                <div class="meta-post-box">
                    <span>Створено: <?php echo e($data->created_at); ?></span> ,
                    <span>Переглядів: <?php echo e($data->previews); ?></span>

                </div>

                <div class="my-2">
                    <?php echo $data->page; ?>

                </div>
                <!-- /.my-2 -->
            </div>
        </div>
        <!-- /.row -->
        <div class="rom mt-2 justify-content-center align-items-center">

        </div>
        <!-- /.rom mt-2 -->
    </div>
    <!-- /.container -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\SERVER_ONE\OpenServer\domains\service.laravel.lc.io\resources\views/pages/page/page.blade.php ENDPATH**/ ?>