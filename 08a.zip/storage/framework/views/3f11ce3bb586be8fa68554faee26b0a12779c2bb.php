<?php $__env->startSection('text-title'); ?> Статті <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <h4 class="text-center">Статті</h4>
                <hr>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card mb-3">
                        <div style="
                            background-image: url(<?php echo e($item->main_img); ?>);
                            background-position: center;
                            background-repeat: repeat-x;
                            height: 13rem;
                            position:relative;
                            "></div>
                        <div class="title-post-card">
                            <a
                                href="<?php echo e(route('post', ['id_alias' => $item->id.'-'.$item->alias.'.html'])); ?>">
                                <?php echo e($item->title); ?>

                            </a>
                        </div>
                        <!-- /.title-post-card -->

                        <div class="card-body">
                            <p class="card-text"><?php echo $item->short_text; ?></p>
                            <p class="card-text">
                                <small class="text-muted">Оновлено <?php echo e($item->updated_at); ?></small>,
                                <small class="text-muted">Перегляди <?php echo e($item->previews); ?></small>
                            </p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <!-- /.col-nd-10 -->
        </div>
        <!-- /.row -->
        <div class="rom mt-2 justify-content-center align-items-center">
            <?php echo e($data->links()); ?>

        </div>
        <!-- /.rom mt-2 -->
    </div>
    <!-- /.container -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\SERVER_ONE\OpenServer\domains\service.laravel.lc.io\resources\views/pages/post/list.blade.php ENDPATH**/ ?>