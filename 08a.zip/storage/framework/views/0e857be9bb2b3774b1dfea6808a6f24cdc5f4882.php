<?php $__env->startSection('text-title'); ?> Список cтатей <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-9">
                <h3>Статті</h3>
                <div class="table-response">
                    <table class="table">
                        <thead>
                        <tr>
                            <th>ID</th>
                            <th>Створено</th>
                            <th>Категорія</th>
                            <th>Назва</th>
                            <th>Контроль</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td> <?php echo e($item->post_id); ?> </td>
                                <td> <?php echo e($item->created_at); ?> </td>
                                <td> <?php echo e($item->title); ?> </td>


                                <td><?php echo e($item->post_title); ?></td>
                                <td>

                                        <?php if($item->public == '1'): ?>
                                        <a href="<?php echo e(route('trigger-public-post',['id'=>$item->post_id])); ?>" title="Вимкнути публікацію">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                        <?php else: ?>
                                            <a href="<?php echo e(route('trigger-public-post',['id'=>$item->post_id])); ?>" title="Увімкнути публікацію">
                                                <i class="fas fa-eye-slash"></i>
                                            </a>
                                        <?php endif; ?>
                                    </a> |
                                    <a href="<?php echo e(route('update-page', ['alias'=>'ggg'])); ?>">
                                        <i class="fas fa-edit"></i>
                                    </a> |
                                    <a href="<?php echo e(route('delete-post', ['id' => $item->post_id])); ?>">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <!-- /.table -->
                </div>
                <!-- /.table-response -->
                <div class="d-flex justify-content-center align-items-center my-2" id="paginate">
                    <?php echo e($data->links()); ?>

                </div>
                <!-- /#paginate.d-flex -->
            </div>
            <!-- /.col-md-9 -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\SERVER_ONE\OpenServer\domains\service.laravel.lc.io\resources\views/admin/pages/posts/list.blade.php ENDPATH**/ ?>