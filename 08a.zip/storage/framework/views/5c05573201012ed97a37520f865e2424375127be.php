<?php $__env->startSection('text-title'); ?> Список моїх токенів API <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-lg-10">
                <h4>Сптсок моїх токенів</h4>

                <table class="table">
                    <thead>
                        <tr>
                            <th>Токен</th>
                            <th>Задіяний</th>
                            <th>Редагувати</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->token); ?></td>
                                <td><?php echo e($item->request_count); ?></td>
                                <td>
                                    <a href="/admin/token/toggle/<?php echo e($item->token); ?>">Увікнути/Вимкнути</a> |
                                    <a href="/admin/token/delete/<?php echo e($item->token); ?>">Видалити</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <div class="d-flex py-3 justify-content-center align-items-center">
                    <?php echo e($data->links()); ?>

                </div>
            </div>
            <!-- /.col-lg-10 -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\SERVER_ONE\OpenServer\domains\service.laravel.lc.io\resources\views/admin/pages/tokens/list.blade.php ENDPATH**/ ?>