<?php $__env->startSection('text-title'); ?> Головна <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row justify-content-center align-items-center">

            <div class="col-md-10 my-2">
                <h1 class="text-center">Скоротити посилання</h1>
                <?php if(!auth()->check()): ?>
                    <h3 align="center">Ви не авторизовані</h3>
                <?php else: ?>
                    <short-field-component></short-field-component>
                <?php endif; ?>
            </div>
            <!-- /.col-md-10 -->

        </div>
        <!-- /.row -->
        <div class="row mt-3">
            <div class="mt-3 px-1 py-2">
                <h4 class="text-center">Ваші скорочення</h4>
                <div class="table-response">
                    <table class="table">
                        <thead>
                        <tr>
                            <th>Url скорочення</th>
                            <th>Скорочений Url</th>
                            <th>Переходи</th>
                            <th>Додатково</th>
                            <th>Останній перехід</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $my_shorts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->url); ?></td>
                                <td><?php echo e(url('/') . $item->short_id); ?></td>
                                <td><?php echo e($item->linked); ?></td>
                                <td>
                                    <a
                                        rel="nofollow"
                                        title="Відстежити переходи"
                                        href="/log/<?php echo e($item->short_id); ?>">
                                        <i class="fas  fa-eye"></i>
                                    </a>
                                </td>
                                <td> <?php echo e($item->updated_at); ?> </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <!-- /.table -->
                </div>
                <!-- /.table-response -->

                <div class="d-flex py-3 mt-1 justify-content-center align-items-center">
                    <?php echo e($my_shorts->links()); ?>

                </div>
            </div>
            <!-- /.px-1 -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container -->



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\SERVER_ONE\OpenServer\domains\service.laravel.lc.io\resources\views/welcome.blade.php ENDPATH**/ ?>